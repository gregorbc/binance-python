# Binance Futures Bot V18.4 - Máximo Rendimiento 9.81 USDT

Sistema de trading automático con IA técnica, Flask + SocketIO, interfaz en tiempo real y gestión avanzada de riesgo.

## Ejecución
```bash
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
./start.sh
```
